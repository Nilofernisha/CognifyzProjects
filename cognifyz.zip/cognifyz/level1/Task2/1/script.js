document.getElementById('colorButton').addEventListener('click', function() {
    this.classList.toggle('clicked');
});
