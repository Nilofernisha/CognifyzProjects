function toggleMenu() {
    var menu = document.getElementById('nav-menu');
    menu.classList.toggle('show');
}
