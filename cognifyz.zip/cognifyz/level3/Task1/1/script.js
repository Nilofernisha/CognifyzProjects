function showImage(element) {
    var mainImage = document.getElementById('mainImage');
    mainImage.src = element.src;
}
